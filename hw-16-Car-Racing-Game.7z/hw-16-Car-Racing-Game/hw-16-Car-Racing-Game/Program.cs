﻿namespace RacingGame
{
    public delegate void SpeedUpdatedHandler(string carName, int speed, int progress);
    public delegate void RaceStatusHandler(string message);

    public abstract class Car
    {
        public string Name { get; protected set; }
        public int Speed { get; private set; }
        public int Distance { get; private set; }

        private readonly Random _rng = new();

        public event SpeedUpdatedHandler SpeedUpdated;
        public static event RaceStatusHandler RaceStarted;
        public static event RaceStatusHandler RaceEnded;

        public abstract void Drive();

        protected void UpdateSpeed(int minSpeed, int maxSpeed)
        {
            Speed = _rng.Next(minSpeed, maxSpeed);
            Distance += Speed;
            int progress = (Distance * 100) / 1000;
            SpeedUpdated?.Invoke(Name, Speed, progress);
        }

        public static void StartRace()
        {
            RaceStarted?.Invoke("The race has started!");
        }

        public static void AnnounceWinner(string winner)
        {
            RaceEnded?.Invoke($"{winner} has won the race!");
        }
    }

    public class SportsCar : Car
    {
        public SportsCar()
        {
            Name = "Sports Car";
        }

        public override void Drive()
        {
            UpdateSpeed(60, 110);
        }
    }

    public class Sedan : Car
    {
        public Sedan()
        {
            Name = "Passenger Car";
        }

        public override void Drive()
        {
            UpdateSpeed(50, 90);
        }
    }

    public class HeavyTruck : Car
    {
        public HeavyTruck()
        {
            Name = "Truck";
        }

        public override void Drive()
        {
            UpdateSpeed(40, 70);
        }
    }

    public class PublicBus : Car
    {
        public PublicBus()
        {
            Name = "Bus";
        }

        public override void Drive()
        {
            UpdateSpeed(35, 75);
        }
    }

    internal class Program
    {
        private static void Main(string[] args)
        {
            var car = new Car[]
            {
                new PublicBus(),
                new HeavyTruck(),
                new Sedan(),
                new SportsCar()
            };

            foreach (var vehicle in car)
            {
                vehicle.SpeedUpdated += DisplayProgress;
            }

            Car.RaceStarted += DisplayStatus;
            Car.RaceEnded += DisplayStatus;

            RunRace(car);
        }

        private static void DisplayStatus(string message)
        {
            Console.WriteLine(message);
        }

        private static void DisplayProgress(string carName, int speed, int progress)
        {
            Console.WriteLine($"{carName} is going {speed} km/h. Progress: {progress}%");
        }

        private static void RunRace(Car[] vehicles)
        {
            const int raceDistance = 1000;
            bool isRaceComplete = false;

            Car.StartRace();

            Thread.Sleep(2000);

            while (!isRaceComplete)
            {
                Console.Clear();

                foreach (var vehicle in vehicles)
                {
                    vehicle.Drive();

                    if (vehicle.Distance >= raceDistance)
                    {
                        isRaceComplete = true;
                        Car.AnnounceWinner(vehicle.Name);
                        break;
                    }
                }

                Thread.Sleep(500);
            }
        }
    }
}
